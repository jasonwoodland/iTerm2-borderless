# Create the following icons:
# Filename             Size in pixels
# icon_16x16.png       16x16
# icon_16x16@2x.png    32x32
# icon_32x32@2x.png    64x64
# icon_128x128.png     128x128
# icon_128x128@2x.png  256x256
# icon_256x256@2x.png  512x512
# icon_512x512@2x.png  1024x1024
#
# And run this script to fill in the missing ones.

cp icon_16x16@2x.png icon_32x32.png
cp icon_128x128@2x.png icon_256x256.png
cp icon_256x256@2x.png icon_512x512.png
