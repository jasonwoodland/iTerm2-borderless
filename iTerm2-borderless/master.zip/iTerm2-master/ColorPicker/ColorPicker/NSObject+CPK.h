#import <Cocoa/Cocoa.h>

@interface NSObject (CPK)

- (NSImage *)cpk_imageNamed:(NSString *)name;

@end
