//
//  NSView+RecursiveDescription.h
//  iTerm
//
//  Created by George Nachman on 11/18/13.
//
//

#import <Cocoa/Cocoa.h>

@interface NSView (RecursiveDescription)

- (NSString *)iterm_recursiveDescription;

@end
