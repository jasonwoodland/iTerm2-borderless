//
//  NSColor+Scripting.h
//  iTerm2
//
//  Created by George Nachman on 8/19/14.
//
//

#import <Cocoa/Cocoa.h>

// This category is used by applescript to convert RGBColor to/from NSColor.
@interface NSColor (Scripting)

@end
