//
//  ProfilesAdvancedPreferencesViewController.h
//  iTerm
//
//  Created by George Nachman on 4/19/14.
//
//

#import "iTermProfilePreferencesBaseViewController.h"

@interface ProfilesAdvancedPreferencesViewController : iTermProfilePreferencesBaseViewController
- (void)layoutSubviewsForEditCurrentSessionMode;
@end
