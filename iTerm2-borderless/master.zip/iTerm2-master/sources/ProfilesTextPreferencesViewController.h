//
//  ProfilesTextPreferencesViewController.h
//  iTerm
//
//  Created by George Nachman on 4/15/14.
//
//

#import "iTermProfilePreferencesBaseViewController.h"

@interface ProfilesTextPreferencesViewController : iTermProfilePreferencesBaseViewController

- (void)changeFont:(id)fontManager;

@end
