//
//  NSApplication+iTerm.h
//  iTerm2
//
//  Created by George Nachman on 7/4/15.
//
//

#import <Cocoa/Cocoa.h>

@interface NSApplication (iTerm)

- (BOOL)isRunningUnitTests;

@end
