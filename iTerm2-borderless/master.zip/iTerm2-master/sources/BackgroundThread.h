//
//  BackgroundThread.h
//  iTerm
//
//  Created by George Nachman on 3/1/12.
//

#import <Foundation/Foundation.h>

@interface BackgroundThread : NSThread

+ (NSThread *)backgroundThread;

@end
