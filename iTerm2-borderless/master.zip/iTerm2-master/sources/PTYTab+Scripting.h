//
//  PTYTab+Scripting.h
//  iTerm2
//
//  Created by George Nachman on 8/26/14.
//
//

#import "PTYTab.h"

// Contains methods exposed in sdef file but not used internally.
@interface PTYTab (Scripting)

@end
